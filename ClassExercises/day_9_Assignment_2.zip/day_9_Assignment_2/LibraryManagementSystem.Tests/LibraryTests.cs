﻿using NUnit.Framework; // 
using LibraryManagementSystem;
using System.Linq;

namespace LibraryManagementSystem.Tests
{
    [TestFixture]
    public class LibraryTests
    {
        private Library _library;

        [SetUp]
        public void Setup()
        {
            _library = new Library();
        }

        [Test]
        public void AddBook_ShouldAddCorrectly()
        {
            var book = new Book("Book 1", "Author A", "111");
            _library.AddBook(book);
            Assert.That(_library.Books, Contains.Item(book)); 
        }

        [Test]
        public void RegisterBorrower_ShouldRegisterCorrectly()
        {
            var borrower = new Borrower("Rocky", "ID007");
            _library.RegisterBorrower(borrower);
            Assert.That(_library.Borrowers, Contains.Item(borrower));
        }

        [Test]
        public void BorrowBook_ShouldUpdateStatusAndAssociation()
        {
            var book = new Book("Title", "Author", "ISBN123");
            var borrower = new Borrower("Name", "ID123");
            _library.AddBook(book);
            _library.RegisterBorrower(borrower);

            _library.BorrowBook("ISBN123", "ID123");

            Assert.Multiple(() =>
            {
                Assert.That(book.IsBorrowed, Is.True); 
                Assert.That(borrower.BorrowedBooks, Contains.Item(book)); 
            });
        }

        [Test]
        public void ReturnBook_ShouldResetStatusAndRemoveAssociation()
        {
            var book = new Book("Title", "Author", "ISBN123");
            var borrower = new Borrower("Name", "ID123");
            _library.AddBook(book);
            _library.RegisterBorrower(borrower);
            _library.BorrowBook("ISBN123", "ID123");

            _library.ReturnBook("ISBN123", "ID123");

            Assert.Multiple(() =>
            {
                 Assert.That(book.IsBorrowed, Is.False); 
                Assert.That(borrower.BorrowedBooks, Is.Empty); 
            });
        }
    }
}
