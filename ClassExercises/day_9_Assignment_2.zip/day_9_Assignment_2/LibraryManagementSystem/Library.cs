﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementSystem
{
    public class Library
    {
        public List<Book> Books { get; set; } = new List<Book>(); 
        public List<Borrower> Borrowers { get; set; } = new List<Borrower>();

        public void AddBook(Book book)
        {
            Books.Add(book); 
            Console.WriteLine($"Book '{book.Title}' added successfully.");
        }

        public void RegisterBorrower(Borrower borrower)
        {
            Borrowers.Add(borrower); 
            Console.WriteLine($"Borrower '{borrower.Name}' registered successfully."); 
        }

        public void BorrowBook(string isbn, string libraryCardNumber)
        {
            var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed); 
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);

            if (book != null && borrower != null)
            {
                book.Borrow();
                borrower.BorrowBook(book); 
            }
        }

        public void ReturnBook(string isbn, string libraryCardNumber)
        {
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);
            var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn); 

            if (book != null && borrower != null)
            {
                book.Return(); 
                borrower.ReturnBook(book); 
            }
        }

        public void ViewBooks()
        {
            Console.WriteLine("\n--- Library Books ---");
            foreach (var b in Books)
                Console.WriteLine($"{b.Title} | {b.Author} | ISBN: {b.ISBN} | Status: {(b.IsBorrowed ? "Borrowed" : "Available")}"); 
        }

        public void ViewBorrowers()
        {
            Console.WriteLine("\n--- Borrowers ---"); 
            foreach (var b in Borrowers)
                Console.WriteLine($"{b.Name} | ID: {b.LibraryCardNumber} | Books: {string.Join(", ", b.BorrowedBooks.Select(x => x.Title))}"); 
        }
    }
}