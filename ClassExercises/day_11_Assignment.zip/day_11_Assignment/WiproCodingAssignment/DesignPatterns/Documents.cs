﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproCodingAssignment.DesignPatterns
{
    public interface IDocument
    {
        void Open();
    }

    public class PdfDocument : IDocument
    {
        public void Open() => Console.WriteLine("Opening PDF Document...");
    }

    public class WordDocument : IDocument
    {
        public void Open() => Console.WriteLine("Opening Word Document...");
    }
}
