﻿using WiproCodingAssignment.SOLID;
using WiproCodingAssignment.DesignPatterns;

// --- SOLID Implementation ---
var generator = new ReportGenerator();
var rawData = generator.GenerateRawData();

// We can swap PdfFormatter for ExcelFormatter easily (OCP/LSP)
var reportService = new ReportService(new PdfFormatter(), new ReportSaver());
reportService.ProcessReport(rawData, "MonthlyReport.pdf");

// --- Factory Pattern Implementation ---
var myDoc = DocumentFactory.CreateDocument("word");
myDoc.Open();