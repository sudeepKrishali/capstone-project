﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproCodingAssignment.SOLID
{
    // SRP: Only responsible for generating report data 
    public class ReportGenerator
    {
        public string GenerateRawData() => "Report Content: Performance Data 2024";
    }

  // OCP: New formats can be added without changing the Formatter class 
    public class PdfFormatter : IReportFormatter
    {
        public string Format(string data) => $"[PDF Format] {data}";
    }

    public class ExcelFormatter : IReportFormatter
    {
        public string Format(string data) => $"[Excel Format] {data}";
    }

   // SRP: Only responsible for file I/O 
    public class ReportSaver : IReportSaver
    {
        public void Save(string filename, string content)
        {
            Console.WriteLine($"Saving report to {filename}...");
            // Real logic for file saving would go here
        }
    }
}
