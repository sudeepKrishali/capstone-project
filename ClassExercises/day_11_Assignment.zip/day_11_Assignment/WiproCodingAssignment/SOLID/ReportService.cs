﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproCodingAssignment.SOLID
{
    public class ReportService
    {
        private readonly IReportFormatter _formatter;
        private readonly IReportSaver _saver;

        // DIP: Dependency Injection via Constructor
        public ReportService(IReportFormatter formatter, IReportSaver saver)
        {
            _formatter = formatter;
            _saver = saver;
        }

        public void ProcessReport(string data, string filename)
        {
            var formatted = _formatter.Format(data);
            _saver.Save(filename, formatted);
        }
    }
}
