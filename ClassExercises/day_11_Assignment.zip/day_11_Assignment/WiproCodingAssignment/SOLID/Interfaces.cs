﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproCodingAssignment.SOLID
{
    // ISP: Separate interfaces so classes only implement what they need
    public interface IReportFormatter
    {
        string Format(string data);
    }

    public interface IReportSaver
    {
        void Save(string filename, string content);
    }
}
