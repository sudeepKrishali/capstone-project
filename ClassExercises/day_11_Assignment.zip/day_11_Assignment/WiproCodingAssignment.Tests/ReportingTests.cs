using Xunit;
using WiproCodingAssignment.SOLID;
using WiproCodingAssignment.DesignPatterns;

namespace WiproCodingAssignment.Tests
{
    public class ReportingTests
    {
        [Fact]
        public void PdfFormatter_ShouldReturn_PdfPrefix()
        {
            // Arrange
            var formatter = new PdfFormatter();
            string data = "Test Data";

            // Act
            var result = formatter.Format(data);

            // Assert
            Assert.Contains("[PDF Format]", result); // Validates OCP implementation
        }

        [Fact]
        public void Factory_ShouldReturn_CorrectType()
        {
            // Arrange & Act
            var doc = DocumentFactory.CreateDocument("word");

            // Assert
            Assert.IsType<WordDocument>(doc); // Validates Factory Pattern implementation
        }
    }
}