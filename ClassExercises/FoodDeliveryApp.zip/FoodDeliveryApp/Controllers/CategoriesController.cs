﻿using FoodDeliveryApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodDeliveryApp.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly FoodDeliveryContext _context;
        public CategoriesController(FoodDeliveryContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<Category> categories = _context.categories.ToList();
            return View(categories);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Category c)
        {
            _context.categories.Add(c);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
