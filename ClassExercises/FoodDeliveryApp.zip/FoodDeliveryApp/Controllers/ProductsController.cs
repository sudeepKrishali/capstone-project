﻿using FoodDeliveryApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.Language.Intermediate;
using Microsoft.CodeAnalysis.Scripting.Hosting;
using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly FoodDeliveryContext _context;
        public ProductsController(FoodDeliveryContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<Product> products = _context.products.Include(e => e.categ).ToList();
            return View(products);
        }

        // using procedure
        //public IActionResult Index()
        //{
        //    List<Product> products = _context.products.FromSqlRaw("exec spGetProducts").ToList();
        //    return View(products);
        //}

        public IActionResult fetchProducts(int cid)
        {
            var result = _context.products.Where(e => e.Categid == cid).Select(e => new
            {
                id = e.Id,
                text = e.Name
            });
            return Json(result);
        }

        public IActionResult ProductsByCategory(int id)
        {
            List<Product> products = _context.products.Where(e=>e.Categid == id).ToList();
            return View(products);
        }
        public IActionResult Create()
        {
            ViewBag.Categid = new SelectList(_context.categories.ToList(), "Id", "Name"); 
            return View();
        }

        //[HttpPost]
        // public IActionResult Create(Product p)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.products.Add(p);
        //        _context.SaveChanges();
        //        return RedirectToAction("Index");

        //    }
        //    else
        //    {
        //        ViewBag.Categid = new SelectList(_context.categories.ToList(), "Id", "Name");
        //        return View(p);
        //    }

        //}

        // using procedure

        [HttpPost]
        public IActionResult Create(Product p)
        {
            if (ModelState.IsValid)
            {
                _context.Database.ExecuteSqlRaw("Exec spInsertProduct @name = {0},@category={1}, @price={2}", p.Name, p.Categid, p.price);
                _context.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                ViewBag.Categid = new SelectList(_context.categories.ToList(), "Id", "Name");
                return View(p);
            }

        }


        public IActionResult Edit(int id)
        {
            return View(_context.products.Find(id));
        }

        [HttpPost]
        public IActionResult Edit(Product p)
        {
            _context.products.Update(p);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            return View(_context.products.Find(id));
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeletePost(Product p)
        {
            _context.products.Remove(p);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
