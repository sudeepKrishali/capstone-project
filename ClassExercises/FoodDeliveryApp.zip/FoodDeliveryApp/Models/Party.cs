﻿namespace FoodDeliveryApp.Models
{
    public class Party
    {
        public int Id { get; set; }
        public string? Name { get; set; }
       public bool IsExternal { get; set; }
    }
}
