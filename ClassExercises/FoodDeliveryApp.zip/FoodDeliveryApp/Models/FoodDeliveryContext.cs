﻿ using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Models
{
    public class FoodDeliveryContext : DbContext
    {
        public FoodDeliveryContext(DbContextOptions<FoodDeliveryContext> options) : base(options)
        {

        }
        public DbSet<Category> categories { get; set; }
        public DbSet<Product> products { get; set; }

        public DbSet<Sale> sales { get; set; }
        public DbSet<Party> parties { get; set; }

    }
}
