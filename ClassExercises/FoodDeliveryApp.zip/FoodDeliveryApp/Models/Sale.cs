﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FoodDeliveryApp.Models
{
    [Table("SaleTable")] // table in db will be created with this name
    public class Sale
    {
        public int Id { get; set; }
        [ForeignKey("prod")]
        public int productId { get; set; }
        public Product? prod { get; set; }
        public float price { get; set; }
         
    }
}
