﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreAPI.Models
{
    public class Book
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; } = string.Empty;
        public int AuthorId { get; set; }
        public int PublicationYear { get; set; }
    }
}
