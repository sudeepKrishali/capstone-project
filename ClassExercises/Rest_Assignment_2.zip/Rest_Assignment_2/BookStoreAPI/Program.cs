using Microsoft.EntityFrameworkCore;
using BookStoreAPI.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// This registers the In-Memory database context 
builder.Services.AddDbContext<ApiContext>(opt => opt.UseInMemoryDatabase("BookStore"));

// Add services for controllers to handle API requests 
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// This maps the routes defined in your Controllers 
app.MapControllers();

app.Run();