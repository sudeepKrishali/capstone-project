﻿using Microsoft.AspNetCore.Mvc;
using BookStoreAPI.Data;
using BookStoreAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreAPI.Controllers
{
    [Route("api/[controller]")] // Attribute Routing 
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly ApiContext _context;

        public BooksController(ApiContext context) => _context = context;

        [HttpGet] // GET all books
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks() => await _context.Books.ToListAsync();

        [HttpGet("{id}")] // GET specific book 
        public async Task<ActionResult<Book>> GetBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            return book == null ? NotFound() : book; // 404 handling
        }

        [HttpPost] // POST new book 
        public async Task<ActionResult<Book>> PostBook(Book book)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); // Validation 
            _context.Books.Add(book);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book); // 201 Created
        }

        [HttpPut("{id}")] // PUT update book 
        public async Task<IActionResult> PutBook(int id, Book book)
        {
            if (id != book.Id) return BadRequest();
            _context.Entry(book).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")] // DELETE book 
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
