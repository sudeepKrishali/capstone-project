﻿using BookStoreAPI.Data;
using BookStoreAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class AuthorsController : ControllerBase
{
    private readonly ApiContext _context;
    public AuthorsController(ApiContext context) => _context = context;

    // Custom route for relationship: /api/authors/{authorId}/books 
    [HttpGet("{authorId}/books")]
    public async Task<ActionResult<IEnumerable<Book>>> GetBooksByAuthor(int authorId)
    {
        var authorExists = await _context.Authors.AnyAsync(a => a.Id == authorId);
        if (!authorExists) return NotFound("Author not found");

        return await _context.Books.Where(b => b.AuthorId == authorId).ToListAsync();
    }
}
