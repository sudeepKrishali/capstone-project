using Xunit;
using UserManagementApp.Services;

namespace UserManagementApp.Tests
{
    public class SecurityTests
    {
        [Fact]
        public void TestPasswordHashing() 
        {
            string pass = "MySecret123";
            string hash1 = SecurityService.HashPassword(pass);
            string hash2 = SecurityService.HashPassword(pass);

            Assert.Equal(hash1, hash2);
            Assert.NotEqual(pass, hash1);
        }

        [Fact]
        
        public void TestEncryptionDecryption() 
        {
            string original = "SensitiveInfo";
            string encrypted = SecurityService.Encrypt(original);
            string decrypted = SecurityService.Decrypt(encrypted);

            Assert.Equal(original, decrypted);
            Assert.NotEqual(original, encrypted);
        }
    }
}