﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog;
using UserManagementApp.Models;

namespace UserManagementApp.Services
{
    public class UserManager
    {
        private List<User> _users = new List<User>();

        public UserManager()
        {
           // Configure Serilog 
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/applog.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }

        public void Register(string username, string password)
        {
            try
            {
                string hashedPassword = SecurityService.HashPassword(password);
                _users.Add(new User { Username = username, HashedPassword = hashedPassword });
                Log.Information("User {Username} registered successfully.", username); 
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error during registration for {Username}", username); 
            }
        }

        
        public bool Login(string username, string password) 
        {
            try
            {
                var user = _users.Find(u => u.Username == username);
                if (user != null && user.HashedPassword == SecurityService.HashPassword(password))
                {
                    Log.Information("User {Username} logged in.", username);
                    return true;
                }
                Log.Warning("Failed login attempt for {Username}", username);
                return false;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Login error"); 
                return false;
            }
        }
    }
}
