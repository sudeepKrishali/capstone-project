﻿using UserManagementApp.Services;

var manager = new UserManager();

// Task 1: Demonstrate Registration & Hashing 
Console.WriteLine("Registering user...");
manager.Register("Alice", "SuperSecret123");

// Task 1: Demonstrate Login 
Console.WriteLine("Attempting Login...");
bool isSuccess = manager.Login("Alice", "SuperSecret123");
Console.WriteLine($"Login Successful: {isSuccess}");

// Task 2: Demonstrate Encryption/Decryption 
string sensitiveData = "User SSN: 123-456-789";
string encrypted = SecurityService.Encrypt(sensitiveData);
string decrypted = SecurityService.Decrypt(encrypted);

Console.WriteLine($"Encrypted: {encrypted}");
Console.WriteLine($"Decrypted: {decrypted}");

 Console.WriteLine("Check the /logs folder for the application log file."); 
