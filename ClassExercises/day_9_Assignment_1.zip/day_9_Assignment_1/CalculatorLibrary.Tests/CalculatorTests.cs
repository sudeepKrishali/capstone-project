﻿using Xunit;
using CalculatorLibrary;
using System;

namespace CalculatorLibrary.Tests
{
    public class CalculatorTests
    {
        private readonly Calculator _calculator = new Calculator();

        [Fact]
        public void Add_ValidInputs_ReturnsSum()
        {
            // Act 
            double result = _calculator.Add(10, 5);
            // Assert
            Assert.Equal(15, result);
        }

        [Fact]
        public void Add_ZeroValue_ReturnsSameValue()
        {
            Assert.Equal(5, _calculator.Add(5, 0));
        }

        [Fact]
        public void Subtract_ValidInputs_ReturnsDifference()
        {
            Assert.Equal(5, _calculator.Subtract(10, 5)); 
        }

        [Fact]
        public void Multiply_ValidInputs_ReturnsProduct()
        {
             Assert.Equal(50, _calculator.Multiply(10, 5)); 
        }

        [Fact]
        public void Divide_ValidInputs_ReturnsQuotient()
        {
            Assert.Equal(2, _calculator.Divide(10, 5));
        }

        [Fact]
        public void Divide_ByZero_ThrowsException()
        {
            // Verify handling of division by zero 
            Assert.Throws<DivideByZeroException>(() => _calculator.Divide(10, 0));
        }
    }
}