﻿using System;

namespace CalculatorLibrary
{
    public class Calculator
    {
        // Adds two double values 
        public double Add(double a, double b) { return a + b;}

        // Subtracts b from a 
        public double Subtract(double a, double b) { return a - b; }

        // Multiplies two double values 
        public double Multiply(double a, double b){return  a * b;}

        // Divides a by b with zero-check 
        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                 throw new DivideByZeroException("Cannot divide by zero."); 
            }
            return a / b;
        }
    }
}