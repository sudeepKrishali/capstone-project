﻿using System.ComponentModel.DataAnnotations;

namespace MovieCatalogAPI.Models
{
    public class Movie
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; } = string.Empty;
        public int ReleaseYear { get; set; }
        public int DirectorId { get; set; } // Association 
        public Director? Director { get; set; }
    }
}
