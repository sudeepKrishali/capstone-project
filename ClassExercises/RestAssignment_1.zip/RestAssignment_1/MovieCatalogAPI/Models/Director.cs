﻿using System.ComponentModel.DataAnnotations;

namespace MovieCatalogAPI.Models
{
    public class Director
    {
        public int Id { get; set; }
        [Required] // Basic validation 
        public string Name { get; set; } = string.Empty;
    }
}
