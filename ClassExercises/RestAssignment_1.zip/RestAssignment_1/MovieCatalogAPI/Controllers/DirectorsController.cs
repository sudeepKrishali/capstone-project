﻿using Microsoft.AspNetCore.Mvc;
using MovieCatalogAPI.Data;

namespace MovieCatalogAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DirectorsController : ControllerBase
    {
        // GET api/directors/{directorId}/movies 
        [HttpGet("{directorId}/movies")]
        public IActionResult GetMoviesByDirector(int directorId)
        {
            var director = StaticData.Directors.FirstOrDefault(d => d.Id == directorId);
            if (director == null) return NotFound("Director not found"); 

            var movies = StaticData.Movies.Where(m => m.DirectorId == directorId).ToList();
            return Ok(movies);
        }
    }
}