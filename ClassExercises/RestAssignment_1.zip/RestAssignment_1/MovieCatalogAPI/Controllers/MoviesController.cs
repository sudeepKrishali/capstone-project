﻿using Microsoft.AspNetCore.Mvc;
using MovieCatalogAPI.Models;
using MovieCatalogAPI.Data;

namespace MovieCatalogAPI.Controllers
{
    [Route("api/[controller]")] // Attribute Routing 
    [ApiController]
    public class MoviesController : ControllerBase
    {
        [HttpGet] // Get all movies 
        public IActionResult GetMovies() => Ok(StaticData.Movies);

        [HttpGet("{id}")] // Get movie by ID
        public IActionResult GetMovie(int id)
        {
            var movie = StaticData.Movies.FirstOrDefault(m => m.Id == id);
            if (movie == null) return NotFound(); // Error handling 
            return Ok(movie);
        }

        [HttpPost] // Create movie 
        public IActionResult CreateMovie(Movie movie)
        {
            movie.Id = StaticData.Movies.Max(m => m.Id) + 1;
            StaticData.Movies.Add(movie);
            return CreatedAtAction(nameof(GetMovie), new { id = movie.Id }, movie);  
        }

        [HttpPut("{id}")] // Update movie 
        public IActionResult UpdateMovie(int id, Movie movie)
        {
            var existing = StaticData.Movies.FirstOrDefault(m => m.Id == id);
            if (existing == null) return NotFound();

            existing.Title = movie.Title;
            existing.ReleaseYear = movie.ReleaseYear;
            existing.DirectorId = movie.DirectorId;
            return NoContent();
        }

        [HttpDelete("{id}")] // Delete movie 
        public IActionResult DeleteMovie(int id)
        {
            var movie = StaticData.Movies.FirstOrDefault(m => m.Id == id);
            if (movie == null) return NotFound();
            StaticData.Movies.Remove(movie);
            return NoContent();
        }
    }
}